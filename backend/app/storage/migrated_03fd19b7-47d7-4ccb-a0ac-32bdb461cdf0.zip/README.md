# Migrated FastAPI Application

This application was automatically migrated from a legacy framework.

## Setup

```bash
pip install -r requirements.txt
```

## Run

```bash
uvicorn main:app --reload
```

## Notes

- Review all migrated code
- Update database connections
- Configure environment variables
- Test all endpoints
