from sqlalchemy import Column, Integer, String, Boolean, DateTime, Float, ForeignKey, Text
from sqlalchemy.orm import relationship, declarative_base
from sqlalchemy.ext.declarative import declarative_base
from pydantic import BaseModel, Field, EmailStr, validator
from typing import Optional, List
from datetime import datetime
from enum import Enum

Base = declarative_base()

# Database Models (SQLAlchemy)



class IncomeCategory(Base):
    """SQLAlchemy model for IncomeCategory"""
    __tablename__ = "incomecategorys"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(50), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"))
    user = relationship("User", back_populates="incomecategorys")
    
    def __repr__(self):
        return f"<IncomeCategory(id={self.id})>"


class ExpenseCategory(Base):
    """SQLAlchemy model for ExpenseCategory"""
    __tablename__ = "expensecategorys"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(50), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"))
    user = relationship("User", back_populates="expensecategorys")
    
    def __repr__(self):
        return f"<ExpenseCategory(id={self.id})>"


class Income(Base):
    """SQLAlchemy model for Income"""
    __tablename__ = "incomes"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(50), nullable=False)
    note = Column(Text, nullable=False)
    amount = Column(Float, nullable=False)
    date = Column(DateTime, nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"))
    category_id = Column(Integer, ForeignKey("incomecategorys.id"))
    user = relationship("User", back_populates="incomes")
    category = relationship("IncomeCategory", back_populates="incomes")
    
    def __repr__(self):
        return f"<Income(id={self.id})>"


class Expense(Base):
    """SQLAlchemy model for Expense"""
    __tablename__ = "expenses"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(50), nullable=False)
    note = Column(Text, nullable=False)
    amount = Column(Float, nullable=False)
    date = Column(DateTime, nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"))
    category_id = Column(Integer, ForeignKey("expensecategorys.id"))
    user = relationship("User", back_populates="expenses")
    category = relationship("ExpenseCategory", back_populates="expenses")
    
    def __repr__(self):
        return f"<Expense(id={self.id})>"


class Budget(Base):
    """SQLAlchemy model for Budget"""
    __tablename__ = "budgets"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(50), nullable=False)
    details = Column(String(100), nullable=False)
    balance = Column(Float, nullable=False, default=0)
    user_id = Column(Integer, ForeignKey("users.id"))
    user = relationship("User", back_populates="budgets")
    
    def __repr__(self):
        return f"<Budget(id={self.id})>"


class Account(Base):
    """SQLAlchemy model for Account"""
    __tablename__ = "accounts"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(50), nullable=False)
    details = Column(String(100), nullable=False)
    balance = Column(Float, nullable=False, default=0)
    user_id = Column(Integer, ForeignKey("users.id"))
    user = relationship("User", back_populates="accounts")
    
    def __repr__(self):
        return f"<Account(id={self.id})>"


# Pydantic Schemas (for API validation)


class IncomeCategoryBase(BaseModel):
    """Base schema for IncomeCategory"""
    name: str
    user: int

class IncomeCategoryCreate(IncomeCategoryBase):
    """Schema for creating IncomeCategory"""
    pass

class IncomeCategoryUpdate(BaseModel):
    """Schema for updating IncomeCategory"""
    name: Optional[str
    user: Optional[int

class IncomeCategoryResponse(IncomeCategoryBase):
    """Schema for IncomeCategory response"""
    id: int
    
    class Config:
        from_attributes = True


class ExpenseCategoryBase(BaseModel):
    """Base schema for ExpenseCategory"""
    name: str
    user: int

class ExpenseCategoryCreate(ExpenseCategoryBase):
    """Schema for creating ExpenseCategory"""
    pass

class ExpenseCategoryUpdate(BaseModel):
    """Schema for updating ExpenseCategory"""
    name: Optional[str
    user: Optional[int

class ExpenseCategoryResponse(ExpenseCategoryBase):
    """Schema for ExpenseCategory response"""
    id: int
    
    class Config:
        from_attributes = True


class IncomeBase(BaseModel):
    """Base schema for Income"""
    name: str
    note: str
    amount: float
    date: datetime
    user: int
    category: int

class IncomeCreate(IncomeBase):
    """Schema for creating Income"""
    pass

class IncomeUpdate(BaseModel):
    """Schema for updating Income"""
    name: Optional[str
    note: Optional[str
    amount: Optional[float
    date: Optional[datetime
    user: Optional[int
    category: Optional[int

class IncomeResponse(IncomeBase):
    """Schema for Income response"""
    id: int
    
    class Config:
        from_attributes = True


class ExpenseBase(BaseModel):
    """Base schema for Expense"""
    name: str
    note: str
    amount: float
    date: datetime
    user: int
    category: int

class ExpenseCreate(ExpenseBase):
    """Schema for creating Expense"""
    pass

class ExpenseUpdate(BaseModel):
    """Schema for updating Expense"""
    name: Optional[str
    note: Optional[str
    amount: Optional[float
    date: Optional[datetime
    user: Optional[int
    category: Optional[int

class ExpenseResponse(ExpenseBase):
    """Schema for Expense response"""
    id: int
    
    class Config:
        from_attributes = True


class BudgetBase(BaseModel):
    """Base schema for Budget"""
    name: str
    details: str
    balance: float
    user: int

class BudgetCreate(BudgetBase):
    """Schema for creating Budget"""
    pass

class BudgetUpdate(BaseModel):
    """Schema for updating Budget"""
    name: Optional[str
    details: Optional[str
    balance: Optional[float
    user: Optional[int

class BudgetResponse(BudgetBase):
    """Schema for Budget response"""
    id: int
    
    class Config:
        from_attributes = True


class AccountBase(BaseModel):
    """Base schema for Account"""
    name: str
    details: str
    balance: float
    user: int

class AccountCreate(AccountBase):
    """Schema for creating Account"""
    pass

class AccountUpdate(BaseModel):
    """Schema for updating Account"""
    name: Optional[str
    details: Optional[str
    balance: Optional[float
    user: Optional[int

class AccountResponse(AccountBase):
    """Schema for Account response"""
    id: int
    
    class Config:
        from_attributes = True


# CRUD Operations

from sqlalchemy.orm import Session
from fastapi import HTTPException


# CRUD for IncomeCategory

def create_incomecategory(db: Session, incomecategory: IncomeCategoryCreate) -> IncomeCategory:
    """Create new IncomeCategory"""
    db_incomecategory = IncomeCategory(**incomecategory.dict())
    db.add(db_incomecategory)
    db.commit()
    db.refresh(db_incomecategory)
    return db_incomecategory

def get_incomecategory(db: Session, incomecategory_id: int) -> Optional[IncomeCategory]:
    """Get IncomeCategory by ID"""
    return db.query(IncomeCategory).filter(IncomeCategory.id == incomecategory_id).first()

def get_incomecategorys(db: Session, skip: int = 0, limit: int = 100) -> List[IncomeCategory]:
    """Get list of IncomeCategorys"""
    return db.query(IncomeCategory).offset(skip).limit(limit).all()

def update_incomecategory(db: Session, incomecategory_id: int, incomecategory: IncomeCategoryUpdate) -> Optional[IncomeCategory]:
    """Update IncomeCategory"""
    db_incomecategory = db.query(IncomeCategory).filter(IncomeCategory.id == incomecategory_id).first()
    if not db_incomecategory:
        return None
    
    update_data = incomecategory.dict(exclude_unset=True)
    for key, value in update_data.items():
        setattr(db_incomecategory, key, value)
    
    db.commit()
    db.refresh(db_incomecategory)
    return db_incomecategory

def delete_incomecategory(db: Session, incomecategory_id: int) -> bool:
    """Delete IncomeCategory"""
    db_incomecategory = db.query(IncomeCategory).filter(IncomeCategory.id == incomecategory_id).first()
    if not db_incomecategory:
        return False
    
    db.delete(db_incomecategory)
    db.commit()
    return True

# CRUD for ExpenseCategory

def create_expensecategory(db: Session, expensecategory: ExpenseCategoryCreate) -> ExpenseCategory:
    """Create new ExpenseCategory"""
    db_expensecategory = ExpenseCategory(**expensecategory.dict())
    db.add(db_expensecategory)
    db.commit()
    db.refresh(db_expensecategory)
    return db_expensecategory

def get_expensecategory(db: Session, expensecategory_id: int) -> Optional[ExpenseCategory]:
    """Get ExpenseCategory by ID"""
    return db.query(ExpenseCategory).filter(ExpenseCategory.id == expensecategory_id).first()

def get_expensecategorys(db: Session, skip: int = 0, limit: int = 100) -> List[ExpenseCategory]:
    """Get list of ExpenseCategorys"""
    return db.query(ExpenseCategory).offset(skip).limit(limit).all()

def update_expensecategory(db: Session, expensecategory_id: int, expensecategory: ExpenseCategoryUpdate) -> Optional[ExpenseCategory]:
    """Update ExpenseCategory"""
    db_expensecategory = db.query(ExpenseCategory).filter(ExpenseCategory.id == expensecategory_id).first()
    if not db_expensecategory:
        return None
    
    update_data = expensecategory.dict(exclude_unset=True)
    for key, value in update_data.items():
        setattr(db_expensecategory, key, value)
    
    db.commit()
    db.refresh(db_expensecategory)
    return db_expensecategory

def delete_expensecategory(db: Session, expensecategory_id: int) -> bool:
    """Delete ExpenseCategory"""
    db_expensecategory = db.query(ExpenseCategory).filter(ExpenseCategory.id == expensecategory_id).first()
    if not db_expensecategory:
        return False
    
    db.delete(db_expensecategory)
    db.commit()
    return True

# CRUD for Income

def create_income(db: Session, income: IncomeCreate) -> Income:
    """Create new Income"""
    db_income = Income(**income.dict())
    db.add(db_income)
    db.commit()
    db.refresh(db_income)
    return db_income

def get_income(db: Session, income_id: int) -> Optional[Income]:
    """Get Income by ID"""
    return db.query(Income).filter(Income.id == income_id).first()

def get_incomes(db: Session, skip: int = 0, limit: int = 100) -> List[Income]:
    """Get list of Incomes"""
    return db.query(Income).offset(skip).limit(limit).all()

def update_income(db: Session, income_id: int, income: IncomeUpdate) -> Optional[Income]:
    """Update Income"""
    db_income = db.query(Income).filter(Income.id == income_id).first()
    if not db_income:
        return None
    
    update_data = income.dict(exclude_unset=True)
    for key, value in update_data.items():
        setattr(db_income, key, value)
    
    db.commit()
    db.refresh(db_income)
    return db_income

def delete_income(db: Session, income_id: int) -> bool:
    """Delete Income"""
    db_income = db.query(Income).filter(Income.id == income_id).first()
    if not db_income:
        return False
    
    db.delete(db_income)
    db.commit()
    return True

# TODO: Generate CRUD operations for remaining 3 models


# Database Setup
# Add this to your main.py or database.py:
# 
# from sqlalchemy import create_engine
# from sqlalchemy.orm import sessionmaker
# 
# DATABASE_URL = "postgresql://user:password@localhost/dbname"
# # or for SQLite: "sqlite:///./app.db"
# 
# engine = create_engine(DATABASE_URL)
# SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
# Base.metadata.create_all(bind=engine)
# 
# def get_db():
#     db = SessionLocal()
#     try:
#         yield db
#     finally:
#         db.close()
