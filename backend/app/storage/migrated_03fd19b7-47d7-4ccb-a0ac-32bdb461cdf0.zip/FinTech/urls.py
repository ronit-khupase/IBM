from fastapi import APIRouter

router = APIRouter()

# Import your route modules here
# Example:
# from .views import router as views_router
# router.include_router(views_router, prefix="/api/v1", tags=["items"])

# Or include individual routers:
# from . import auth, users, items
# router.include_router(auth.router, prefix="/auth", tags=["authentication"])
# router.include_router(users.router, prefix="/users", tags=["users"])
# router.include_router(items.router, prefix="/items", tags=["items"])
