from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.orm import Session

router = APIRouter()

# No Django views detected in this file
# Add your FastAPI routes here

@router.get("/")
async def root():
    return {"message": "API is running"}
